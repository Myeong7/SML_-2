from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time

browser = webdriver.Chrome("c:/chromedriver.exe")
browser.get("https://map.naver.com/v5/")
browser.implicitly_wait(10)
browser.maximize_window()

# 검색창 입력
search = browser.find_element(By.CSS_SELECTOR, "input.input_search")
search.click()
time.sleep(1)
search.send_keys("정릉동 맛집")
time.sleep(1)
search.send_keys(Keys.ENTER)
time.sleep(2)

browser.switch_to.frame("searchIframe")

browser.find_element(By.CSS_SELECTOR,"#_pcmap_list_scroll_container").click()

lis = browser.find_elements(By.CSS_SELECTOR,"li._1EKsQ")
before_len = len(lis)


browser.implicitly_wait(0)

for li in lis:
    
    if len(li.find_elements(By.CSS_SELECTOR,"span._2FqTn._1mRAM > em")) > 0:
        
        name = li.find_elements(By.CSS_SELECTOR,"span.OXiLu").text
        
        star = li.find_elements(By.CSS_SELECTOR,"span._2FqTn._1mRAM > em").text

        
        if len(li.find_elements(By.CSS_SELECTOR,"span._2FqTn._4DbfT")) > 0:
           
            try:
                visit_review = li.find_elements(By.CSS_SELECTOR,"span._2FqTn:nth-child(3)").text
            except:
                visit_review = "0"
           
            try:
                blog_review = li.find_elements(By.CSS_SELECTOR,"span._2FqTn:nth-child(4)").text
            except:
                blog_review = "0"
      
        else:
            
            try:
                visit_review = li.find_elements(By.CSS_SELECTOR,"span._2FqTn:nth-child(2)").text
            except:
                visit_review = "0"
            
            try:
                blog_review = li.find_elements(By.CSS_SELECTOR,"span._2FqTn:nth-child(3)").text
            except:
                blog_review = "0"

        print(name, star, visit_review, blog_review)